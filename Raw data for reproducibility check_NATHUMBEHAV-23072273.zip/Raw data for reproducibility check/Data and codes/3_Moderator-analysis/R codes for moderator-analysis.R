#install.packages('metafor')#
library(metafor)
library(Hmisc)
mydata=spss.get("D:/submission/CHARLS//Moderator-analysis/moderator-analysis.sav")
print(mydata, row.names=FALSE)
dat = escalc(measure = "OR", ai = tpos, bi = tneg, ci = cpos, di = cneg, data =mydata,
             append = TRUE)

args(rma)
res = rma(ai = tpos, bi = tneg, ci = cpos, di = cneg, data = mydata, measure = "OR")
res
exp(c(0.5265, 0.3532, 0.6998))
confint(res)
forest(res, slab = paste(dat$Survey,  sep = ", "),
       xlim = c(-16, 7), at = log(c(0.5,1,3,5,7)), atransf = exp,
       ilab = cbind(dat$tpos, dat$tneg, dat$cpos, dat$cneg),
       ilab.xpos = c(-9.5, -8, -6, -4.5), cex = 0.75)
op = par(cex = 0.75, font = 2)
text(c(-9.5, -8, -6, -4.5), 9, c("DPN", "Total", "DPN",  "Total"))
text(c(-8.75, -5.25), 10, c("All others", "Married"))
text(-16, 10, "Dataset", pos = 4)
text(6, 9, "OR [95% CI]", pos = 2)
rma(yi, vi, data = dat, subset = (group == "1"))
rma(yi, vi, data = dat, subset = (group == "2"))
rma(yi, vi, mods = ~factor(group) - 1, data = dat)
rma(yi, vi, mods = ~ relevel(factor(group), ref = "2"), data = dat)